from sources.utilities.webdriver_factory import *
from sources.pages.loginPage import login

class HomeVtigerLogin(WebDriverFactory):
    def __init__(self,driver):
        super().__init__(driver)
        self.driver = driver

    def loginToApp(self):
        login(self.driver).login_to_application("admin","root")
